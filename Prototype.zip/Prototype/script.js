
document.addEventListener('DOMContentLoaded', () => {

  /*************** Sign In Modal ***************/
  const signInForm = document.getElementById('modalSignInForm');
  const signInModal = document.getElementById('signInModal');
  const signInSuccess = document.getElementById('signInSuccess');

  if (signInForm && signInModal && signInSuccess) {
    signInForm.addEventListener('submit', function(e) {
      e.preventDefault();
      signInModal.style.display = 'none';       // Close sign in modal
      signInSuccess.style.display = 'block';    // Show success popup
      this.reset();
    });
  }

  // Close Sign In Success Box
  window.closeSignInSuccess = function() {
    if (signInSuccess) signInSuccess.style.display = 'none';
  };

  /*************** Join Workshop Modal ***************/
  const joinModal = document.getElementById('joinModal');
  const successBox = document.getElementById('successBox');

  if (joinModal && successBox) {
    window.submitJoinForm = function() {
      joinModal.style.display = 'none';
      successBox.style.display = 'block';
    };
    window.closeSuccessBox = function() {
      successBox.style.display = 'none';
    };
  }

  /*************** Gallery Upload + Filter ***************/
  const uploadBtn = document.getElementById('uploadBtn');
  const fileInput = document.getElementById('fileInput');
  const galleryGrid = document.getElementById('galleryGrid');
  const filterSelect = document.getElementById('filterSelect');
  const searchInput = document.getElementById('searchInput');
  const viewMineBtn = document.getElementById('viewMineBtn');
  const clearBtn = document.getElementById('clearFilter');

  if (uploadBtn && fileInput && galleryGrid) {

    // Open file picker when upload button clicked
    uploadBtn.addEventListener('click', () => fileInput.click());

    // Helper: create gallery item element
    function createGalleryItem(srcDataUrl, options = {}) {
      const div = document.createElement('div');
      div.className = 'gallery-item';
      div.dataset.type = options.type || 'user';
      div.dataset.title = options.title || 'Uploaded Image';
      const img = document.createElement('img');
      img.src = srcDataUrl;
      img.alt = options.title || 'Uploaded Image';
      div.appendChild(img);
      return div;
    }

    // Handle file input change -> preview in gallery
    fileInput.addEventListener('change', (e) => {
      const files = Array.from(e.target.files || []);
      if (!files.length) return;
      files.forEach(file => {
        if (!file.type.startsWith('image/')) return;
        const reader = new FileReader();
        reader.onload = function(evt) {
          const item = createGalleryItem(evt.target.result, { type: 'user', title: file.name });
          galleryGrid.prepend(item); // newest first
        };
        reader.readAsDataURL(file);
      });
      fileInput.value = '';
      applyFilters();
    });

    // FILTER logic (by select and search)
    function applyFilters() {
      const type = filterSelect.value || 'all';
      const q = (searchInput.value || '').trim().toLowerCase();

      const items = Array.from(galleryGrid.children);
      items.forEach(item => {
        const itemType = (item.dataset.type || '').toLowerCase();
        const title = (item.dataset.title || '').toLowerCase();
        let typeMatch = (type === 'all') || (type === 'user' && itemType === 'user') || (itemType === type);
        let textMatch = !q || title.includes(q);
        if (typeMatch && textMatch) item.classList.remove('hidden');
        else item.classList.add('hidden');
      });
    }

    // Event listeners for filters
    filterSelect.addEventListener('change', applyFilters);
    searchInput.addEventListener('input', applyFilters);
    clearBtn.addEventListener('click', () => {
      filterSelect.value = 'all';
      searchInput.value = '';
      applyFilters();
    });
    viewMineBtn.addEventListener('click', () => {
      filterSelect.value = 'user';
      applyFilters();
    });

    applyFilters(); // initial run
  }

});

 document.addEventListener('DOMContentLoaded', () => {

  /*************** Sign In Modal ***************/
  const signInForm = document.getElementById('modalSignInForm');
  const signInModal = document.getElementById('signInModal');
  const signInSuccess = document.getElementById('signInSuccess');

  if (signInForm && signInModal && signInSuccess) {
    signInForm.addEventListener('submit', function(e) {
      e.preventDefault();
      signInModal.style.display = 'none';       // Close sign in modal
      signInSuccess.style.display = 'block';    // Show success popup
      this.reset();
    });
  }

  // Close Sign In Success Box
  window.closeSignInSuccess = function() {
    if (signInSuccess) signInSuccess.style.display = 'none';
  };

  /*************** Join Workshop Modal ***************/
  const joinModal = document.getElementById('joinModal');
  const successBox = document.getElementById('successBox');

  if (joinModal && successBox) {
    window.submitJoinForm = function() {
      joinModal.style.display = 'none';
      successBox.style.display = 'block';
    };
    window.closeSuccessBox = function() {
      successBox.style.display = 'none';
    };
  }

  /*************** Gallery Upload + Filter ***************/
  const uploadBtn = document.getElementById('uploadBtn');
  const fileInput = document.getElementById('fileInput');
  const galleryGrid = document.getElementById('galleryGrid');
  const filterSelect = document.getElementById('filterSelect');
  const searchInput = document.getElementById('searchInput');
  const viewMineBtn = document.getElementById('viewMineBtn');
  const clearBtn = document.getElementById('clearFilter');

  if (uploadBtn && fileInput && galleryGrid) {

    // Open file picker when upload button clicked
    uploadBtn.addEventListener('click', () => fileInput.click());

    // Helper: create gallery item element
    function createGalleryItem(srcDataUrl, options = {}) {
      const div = document.createElement('div');
      div.className = 'gallery-item';
      div.dataset.type = options.type || 'user';
      div.dataset.title = options.title || 'Uploaded Image';
      const img = document.createElement('img');
      img.src = srcDataUrl;
      img.alt = options.title || 'Uploaded Image';
      div.appendChild(img);
      return div;
    }

    // Handle file input change -> preview in gallery
    fileInput.addEventListener('change', (e) => {
      const files = Array.from(e.target.files || []);
      if (!files.length) return;
      files.forEach(file => {
        if (!file.type.startsWith('image/')) return;
        const reader = new FileReader();
        reader.onload = function(evt) {
          const item = createGalleryItem(evt.target.result, { type: 'user', title: file.name });
          galleryGrid.prepend(item); // newest first
        };
        reader.readAsDataURL(file);
      });
      fileInput.value = '';
      applyFilters();
    });

    // FILTER logic (by select and search)
    function applyFilters() {
      const type = filterSelect.value || 'all';
      const q = (searchInput.value || '').trim().toLowerCase();

      const items = Array.from(galleryGrid.children);
      items.forEach(item => {
        const itemType = (item.dataset.type || '').toLowerCase();
        const title = (item.dataset.title || '').toLowerCase();
        let typeMatch = (type === 'all') || (type === 'user' && itemType === 'user') || (itemType === type);
        let textMatch = !q || title.includes(q);
        if (typeMatch && textMatch) item.classList.remove('hidden');
        else item.classList.add('hidden');
      });
    }

    // Event listeners for filters
    filterSelect.addEventListener('change', applyFilters);
    searchInput.addEventListener('input', applyFilters);
    clearBtn.addEventListener('click', () => {
      filterSelect.value = 'all';
      searchInput.value = '';
      applyFilters();
    });
    viewMineBtn.addEventListener('click', () => {
      filterSelect.value = 'user';
      applyFilters();
    });

    applyFilters(); // initial run
  }


 /*************** Hamburger Menu for Navbar ***************/
  window.toggleNav = function() {
    var x = document.getElementById("navSmall");
    if (x.className.indexOf("w3-show") === -1) {
      x.className += " w3-show";
    } else { 
      x.className = x.className.replace(" w3-show", "");
    }
  };

});
